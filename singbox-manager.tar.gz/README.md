# sing-box Proxy Manager

Lightweight web UI for managing sing-box inbounds. No Docker. Minimal RAM/CPU.

## Install

```bash
git clone / copy files to your server, then:

chmod +x install.sh
sudo ./install.sh
```

Runs on port **8000** by default.
First visit → set a password → done.

## Supported Protocols

| Protocol | TLS Options |
|---|---|
| VLESS | Reality, ACME, Manual cert |
| AnyTLS | ACME (Cloudflare/HTTP), Manual cert |
| TUIC | ACME (Cloudflare/HTTP), Manual cert |
| Hysteria2 | ACME (Cloudflare/HTTP), Manual cert |

## Features

- Add / Edit / Delete inbounds visually
- Auto-generate UUIDs, Reality keypairs, short IDs
- Start / Stop / Restart / Reload sing-box via systemctl
- Live log viewer (journalctl)
- Raw JSON editor with validation before save
- Config backup on every save (.bak)
- Session-based auth with 1h timeout

## Environment Variables

| Var | Default | Description |
|---|---|---|
| `MANAGER_PORT` | 8000 | Web UI port |
| `SINGBOX_CONFIG` | /etc/sing-box/config.json | Config file path |
| `PASSWORD_FILE` | /etc/singbox-manager/password.hash | Password storage |

## Resource Usage

- RAM: ~30-50MB (Flask + Python)
- CPU: minimal (capped at 20% via systemd)
- No database, no Node.js, no Docker

## Service Management

```bash
systemctl status singbox-manager
systemctl restart singbox-manager
journalctl -u singbox-manager -f
```

## Security Notes

- Bind to a specific interface or use SSH tunnel for production:
  `ssh -L 8000:localhost:8000 user@server`
- Passwords stored as PBKDF2-SHA256 hashes
- Change port: `MANAGER_PORT=9000 ./install.sh`
