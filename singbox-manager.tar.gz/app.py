#!/usr/bin/env python3
"""
sing-box Proxy Manager
Lightweight Flask web UI for managing sing-box proxies
"""

import json
import os
import subprocess
import hashlib
import hmac
import time
import uuid
import secrets
import base64
from functools import wraps
from typing import Optional
from flask import Flask, request, jsonify, send_from_directory, session

app = Flask(__name__, static_folder='static')
app.secret_key = os.environ.get('SECRET_KEY', secrets.token_hex(32))

# Configuration
CONFIG_FILE = os.environ.get('SINGBOX_CONFIG', '/etc/sing-box/config.json')
PASSWORD_FILE = os.environ.get('PASSWORD_FILE', '/etc/singbox-manager/password.hash')
AUTO_CERT_DIR = os.environ.get('AUTO_CERT_DIR', '/etc/singbox-manager/certs')
PORT = int(os.environ.get('MANAGER_PORT', 8000))
SESSION_TIMEOUT = 3600  # 1 hour

# ─── Auth ────────────────────────────────────────────────────────────────────

def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
    return f"{salt}:{h.hex()}"

def verify_password(password: str, stored: str) -> bool:
    try:
        salt, hash_hex = stored.split(':', 1)
        h = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
        return hmac.compare_digest(h.hex(), hash_hex)
    except Exception:
        return False

def get_stored_password() -> Optional[str]:
    try:
        with open(PASSWORD_FILE) as f:
            return f.read().strip()
    except FileNotFoundError:
        return None

def save_password(password: str):
    os.makedirs(os.path.dirname(PASSWORD_FILE), exist_ok=True)
    with open(PASSWORD_FILE, 'w') as f:
        f.write(hash_password(password))

def require_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('authenticated'):
            return jsonify({'error': 'Unauthorized'}), 401
        if time.time() - session.get('login_time', 0) > SESSION_TIMEOUT:
            session.clear()
            return jsonify({'error': 'Session expired'}), 401
        return f(*args, **kwargs)
    return decorated

# ─── Config I/O ──────────────────────────────────────────────────────────────

def load_config() -> dict:
    try:
        with open(CONFIG_FILE) as f:
            return json.load(f)
    except FileNotFoundError:
        return {
            "log": {"disabled": False},
            "dns": {
                "servers": [{"type": "tcp", "server": "1.1.1.1", "server_port": 53}],
                "strategy": "prefer_ipv6"
            },
            "inbounds": [],
            "outbounds": [{"type": "direct"}]
        }

def save_config(config: dict):
    os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)

    backup = CONFIG_FILE + '.bak'
    try:
        import shutil
        shutil.copy2(CONFIG_FILE, backup)
    except Exception:
        pass

    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)

def ensure_inbounds(config: dict) -> list:
    inbounds = config.setdefault('inbounds', [])
    if not isinstance(inbounds, list):
        raise ValueError('Config field "inbounds" must be a list')
    return inbounds

def parse_json_request() -> dict:
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise ValueError('Request body must be a JSON object')
    return data

def parse_inbound_id(inbound_id: str, inbounds: list) -> int:
    try:
        index = int(inbound_id)
    except (TypeError, ValueError):
        raise ValueError('Invalid inbound id')

    if index < 0 or index >= len(inbounds):
        raise IndexError('Inbound not found')

    return index

def validate_and_save_config(config: dict):
    check = validate_config(config)

    if not check['valid']:
        output = (check.get('output') or '').strip()
        message = 'Config validation failed'
        if output:
            message = f'{message}: {output}'
        raise ValueError(message)

    save_config(config)

def inbound_with_id(inbound: dict, index: int) -> dict:
    item = dict(inbound)
    item['_id'] = str(index)
    item['_manager'] = get_inbound_manager_meta(item)

    reality = item.get('tls', {}).get('reality', {})
    if reality.get('enabled') and reality.get('private_key'):
        public_key = derive_reality_public_key(reality['private_key'])
        if public_key:
            item['_reality_public_key'] = public_key

    return item

def get_inbound_manager_meta(inbound: dict) -> dict:
    tls = inbound.get('tls', {}) or {}
    cert_path = tls.get('certificate_path', '')
    key_path = tls.get('key_path', '')
    insecure = is_managed_auto_cert(cert_path, key_path)
    return {'insecure': insecure}

def derive_reality_public_key(private_key: str) -> Optional[str]:
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import x25519

        padded = private_key + '=' * (-len(private_key) % 4)
        private_bytes = base64.urlsafe_b64decode(padded.encode())
        key = x25519.X25519PrivateKey.from_private_bytes(private_bytes)
        public_bytes = key.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )
        return base64.urlsafe_b64encode(public_bytes).decode().rstrip('=')
    except Exception:
        return None

def is_managed_auto_cert(cert_path: str, key_path: str) -> bool:
    if not cert_path or not key_path:
        return False

    try:
        cert_real = os.path.realpath(cert_path)
        key_real = os.path.realpath(key_path)
        base_real = os.path.realpath(AUTO_CERT_DIR)
        return cert_real.startswith(base_real) and key_real.startswith(base_real)
    except Exception:
        return False

def slugify(value: str) -> str:
    allowed = []
    for ch in (value or '').lower():
        if ch.isalnum():
            allowed.append(ch)
        elif ch in ('-', '_'):
            allowed.append(ch)
        else:
            allowed.append('-')

    slug = ''.join(allowed).strip('-')
    while '--' in slug:
        slug = slug.replace('--', '-')
    return slug or 'proxy'

def ensure_self_signed_cert(inbound: dict, existing_inbound: Optional[dict] = None) -> tuple[str, str]:
    tls = inbound.setdefault('tls', {})
    existing_tls = (existing_inbound or {}).get('tls', {}) if existing_inbound else {}
    existing_cert = existing_tls.get('certificate_path', '')
    existing_key = existing_tls.get('key_path', '')

    os.makedirs(AUTO_CERT_DIR, exist_ok=True)

    if is_managed_auto_cert(existing_cert, existing_key):
        cert_path = existing_cert
        key_path = existing_key
    else:
        stem_parts = [
            inbound.get('tag') or inbound.get('type') or 'proxy',
            str(inbound.get('listen_port') or 'port'),
            secrets.token_hex(4)
        ]
        stem = slugify('-'.join(stem_parts))
        cert_path = os.path.join(AUTO_CERT_DIR, f'{stem}.crt')
        key_path = os.path.join(AUTO_CERT_DIR, f'{stem}.key')

    common_name = (
        tls.get('server_name')
        or tls.get('reality', {}).get('handshake', {}).get('server')
        or inbound.get('tag')
        or 'localhost'
    )

    result = subprocess.run(
        [
            'openssl', 'req', '-x509', '-newkey', 'rsa:2048', '-sha256',
            '-nodes', '-days', '3650',
            '-subj', f'/CN={common_name}',
            '-keyout', key_path,
            '-out', cert_path
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=20
    )

    if result.returncode != 0:
        raise ValueError((result.stderr or result.stdout or 'Failed to generate self-signed certificate').strip())

    tls['certificate_path'] = cert_path
    tls['key_path'] = key_path
    return cert_path, key_path

def prepare_inbound_for_save(inbound: dict, existing_inbound: Optional[dict] = None) -> dict:
    cleaned = json.loads(json.dumps(inbound))
    manager = cleaned.pop('_manager', {}) or {}
    tls = cleaned.get('tls', {}) or {}
    cleaned['tls'] = tls

    if manager.get('insecure'):
        ensure_self_signed_cert(cleaned, existing_inbound)

    return cleaned

# ─── sing-box control ────────────────────────────────────────────────────────

def singbox_cmd(action: str) -> dict:
    try:
        result = subprocess.run(
            ['systemctl', action, 'sing-box'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=15
        )
        return {'success': result.returncode == 0, 'output': result.stdout + result.stderr}
    except Exception as e:
        return {'success': False, 'output': str(e)}

def singbox_status() -> dict:
    try:
        result = subprocess.run(
            ['systemctl', 'is-active', 'sing-box'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=5
        )

        active = result.stdout.strip() == 'active'

        log_result = subprocess.run(
            ['journalctl', '-u', 'sing-box', '-n', '50', '--no-pager', '--output=short'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=5
        )

        return {
            'active': active,
            'status': result.stdout.strip(),
            'logs': log_result.stdout
        }

    except Exception as e:
        return {'active': False, 'status': 'unknown', 'logs': str(e)}

def validate_config(config: dict) -> dict:
    try:
        import tempfile

        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(config, f)
            tmp = f.name

        result = subprocess.run(
            ['sing-box', 'check', '-c', tmp],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=10
        )

        os.unlink(tmp)

        return {'valid': result.returncode == 0, 'output': result.stdout + result.stderr}

    except Exception as e:
        return {'valid': False, 'output': str(e)}

def generate_reality_keypair() -> dict:
    try:
        result = subprocess.run(
            ['sing-box', 'generate', 'reality-keypair'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=10
        )

        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            kp = {}

            for line in lines:
                if 'PrivateKey:' in line:
                    kp['private_key'] = line.split(':', 1)[1].strip()
                elif 'PublicKey:' in line:
                    kp['public_key'] = line.split(':', 1)[1].strip()

            return kp

        return {}

    except Exception:
        return {}

def get_network_traffic() -> dict:
    """Get real network traffic usage per physical interface"""
    try:
        interfaces = []
        total_download = 0
        total_upload = 0
        
        sys_net_path = '/sys/class/net'
        if not os.path.exists(sys_net_path):
            return {'error': 'Network stats not available', 'interfaces': []}
        
        for iface in os.listdir(sys_net_path):
            # Skip virtual interfaces
            if iface in ('lo',) or any(iface.startswith(prefix) for prefix in ('docker', 'veth', 'br', 'tun', 'tap', 'virbr', 'wg')):
                continue
            
            try:
                rx_bytes_path = os.path.join(sys_net_path, iface, 'statistics', 'rx_bytes')
                tx_bytes_path = os.path.join(sys_net_path, iface, 'statistics', 'tx_bytes')
                
                with open(rx_bytes_path) as f:
                    rx_bytes = int(f.read().strip())
                with open(tx_bytes_path) as f:
                    tx_bytes = int(f.read().strip())
                
                rx_mb = rx_bytes // (1024 * 1024)
                tx_mb = tx_bytes // (1024 * 1024)
                total = rx_mb + tx_mb
                
                total_download += rx_mb
                total_upload += tx_mb
                
                interfaces.append({
                    'name': iface,
                    'download_mb': rx_mb,
                    'download_gb': rx_mb / 1024,
                    'upload_mb': tx_mb,
                    'upload_gb': tx_mb / 1024,
                    'total_mb': total,
                    'total_gb': total / 1024
                })
            except Exception:
                continue
        
        return {
            'success': True,
            'interfaces': sorted(interfaces, key=lambda x: x['total_mb'], reverse=True),
            'total_download_mb': total_download,
            'total_upload_mb': total_upload,
            'total_download_gb': total_download / 1024,
            'total_upload_gb': total_upload / 1024,
            'total_mb': total_download + total_upload,
            'total_gb': (total_download + total_upload) / 1024
        }
    except Exception as e:
        return {'error': str(e), 'interfaces': []}

# ─── Routes ──────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/api/setup', methods=['GET'])
def setup_status():
    has_password = get_stored_password() is not None
    return jsonify({'setup_required': not has_password})

@app.route('/api/setup', methods=['POST'])
def setup():
    if get_stored_password() is not None:
        return jsonify({'error': 'Already set up'}), 400

    data = request.json
    password = data.get('password', '').strip()

    if len(password) < 8:
        return jsonify({'error': 'Password must be at least 8 characters'}), 400

    save_password(password)

    return jsonify({'success': True})

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    stored = get_stored_password()

    if stored is None:
        return jsonify({'error': 'Not set up'}), 400

    if verify_password(data.get('password', ''), stored):
        session['authenticated'] = True
        session['login_time'] = time.time()
        return jsonify({'success': True})

    time.sleep(1)
    return jsonify({'error': 'Invalid password'}), 401

@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True})

@app.route('/api/status', methods=['GET'])
@require_auth
def status():
    return jsonify(singbox_status())

@app.route('/api/traffic', methods=['GET'])
@require_auth
def traffic():
    return jsonify(get_network_traffic())

@app.route('/api/control/<action>', methods=['POST'])
@require_auth
def control(action):
    if action not in ('start', 'stop', 'restart', 'reload'):
        return jsonify({'error': 'Invalid action'}), 400

    return jsonify(singbox_cmd(action))

@app.route('/api/config', methods=['GET'])
@require_auth
def get_config():
    return jsonify(load_config())

@app.route('/api/inbounds', methods=['GET'])
@require_auth
def get_inbounds():
    config = load_config()

    try:
        inbounds = ensure_inbounds(config)
    except ValueError as e:
        return jsonify({'error': str(e)}), 400

    return jsonify([inbound_with_id(inbound, i) for i, inbound in enumerate(inbounds)])

@app.route('/api/inbounds', methods=['POST'])
@require_auth
def create_inbound():
    try:
        inbound = parse_json_request()
        config = load_config()
        inbounds = ensure_inbounds(config)
        inbounds.append(prepare_inbound_for_save(inbound))
        validate_and_save_config(config)
    except ValueError as e:
        return jsonify({'error': str(e)}), 400

    return jsonify({'success': True, 'id': str(len(inbounds) - 1)})

@app.route('/api/inbounds/<inbound_id>', methods=['PUT'])
@require_auth
def update_inbound(inbound_id):
    try:
        inbound = parse_json_request()
        config = load_config()
        inbounds = ensure_inbounds(config)
        index = parse_inbound_id(inbound_id, inbounds)
        inbounds[index] = prepare_inbound_for_save(inbound, inbounds[index])
        validate_and_save_config(config)
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except IndexError as e:
        return jsonify({'error': str(e)}), 404

    return jsonify({'success': True})

@app.route('/api/inbounds/<inbound_id>', methods=['DELETE'])
@require_auth
def delete_inbound(inbound_id):
    try:
        config = load_config()
        inbounds = ensure_inbounds(config)
        index = parse_inbound_id(inbound_id, inbounds)
        deleted = inbounds.pop(index)
        validate_and_save_config(config)
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except IndexError as e:
        return jsonify({'error': str(e)}), 404

    return jsonify({'success': True, 'deleted': deleted})

@app.route('/api/config/raw', methods=['GET'])
@require_auth
def get_config_raw():
    config = load_config()
    return jsonify({'json': json.dumps(config, indent=2)})

@app.route('/api/config/raw', methods=['POST'])
@require_auth
def set_config_raw():
    try:
        data = parse_json_request()
    except ValueError as e:
        return jsonify({'error': str(e)}), 400

    raw_json = data.get('json')
    if not isinstance(raw_json, str):
        return jsonify({'error': 'Field "json" must be a string'}), 400

    try:
        config = json.loads(raw_json)
    except json.JSONDecodeError as e:
        return jsonify({'error': 'Invalid JSON: %s' % e}), 400

    try:
        validate_and_save_config(config)
    except ValueError as e:
        return jsonify({'error': str(e)}), 400

    return jsonify({'success': True})

@app.route('/api/generate/uuid', methods=['GET'])
@require_auth
def gen_uuid():
    return jsonify({'uuid': str(uuid.uuid4()).upper()})

@app.route('/api/generate/short-id', methods=['GET'])
@require_auth
def gen_short_id():
    return jsonify({'short_id': secrets.token_hex(8)})

@app.route('/api/generate/reality-keypair', methods=['GET'])
@require_auth
def gen_reality_keypair():
    kp = generate_reality_keypair()

    if not kp:
        return jsonify({'error': 'Failed to generate keypair'}), 500

    return jsonify(kp)

@app.route('/api/change-password', methods=['POST'])
@require_auth
def change_password():
    try:
        data = parse_json_request()
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    stored = get_stored_password()

    if not verify_password(data.get('current', ''), stored):
        return jsonify({'error': 'Current password incorrect'}), 401

    new_pw = data.get('new', '').strip()

    if len(new_pw) < 8:
        return jsonify({'error': 'Password must be at least 8 characters'}), 400

    save_password(new_pw)

    return jsonify({'success': True})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=PORT, debug=False)
