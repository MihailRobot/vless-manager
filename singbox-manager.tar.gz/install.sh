#!/bin/bash
# Combined sing-box + singbox-manager installer
# Installs sing-box with a starter Reality VLESS inbound
# and installs the lightweight Flask web UI to manage it.

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

info()    { echo -e "${CYAN}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[OK]${NC} $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

[[ ${EUID} -ne 0 ]] && error "Run as root: sudo $0"

INSTALL_DIR="/opt/singbox-manager"
SERVICE_NAME="singbox-manager"
MANAGER_PORT="${MANAGER_PORT:-8000}"
SINGBOX_CONFIG="${SINGBOX_CONFIG:-/etc/sing-box/config.json}"
PASSWORD_FILE="/etc/singbox-manager/password.hash"
AUTO_CERT_DIR="/etc/singbox-manager/certs"
SINGBOX_VERSION="${SINGBOX_VERSION:-1.13.13}"
SINGBOX_ARCHIVE="sing-box-${SINGBOX_VERSION}-linux-amd64.tar.gz"
SINGBOX_URL="https://github.com/SagerNet/sing-box/releases/download/v${SINGBOX_VERSION}/${SINGBOX_ARCHIVE}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo "  ┌──────────────────────────────────────────────┐"
echo "  │      sing-box + Proxy Manager Installer      │"
echo "  └──────────────────────────────────────────────┘"
echo ""

read -r -p "Enter SNI/hostname for starter Reality inbound [default www.bing.com]: " SNI
SNI="${SNI:-www.bing.com}"

read -r -p "Enter port for sing-box inbound [default 443]: " SINGBOX_PORT
SINGBOX_PORT="${SINGBOX_PORT:-443}"

read -r -p "Enter port for web manager [default ${MANAGER_PORT}]: " INPUT_MANAGER_PORT
MANAGER_PORT="${INPUT_MANAGER_PORT:-$MANAGER_PORT}"

info "Using SNI: ${SNI}"
info "Using sing-box port: ${SINGBOX_PORT}"
info "Using manager port: ${MANAGER_PORT}"

info "Installing dependencies..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq \
    python3 python3-pip python3-venv \
    curl openssl iptables-persistent ca-certificates

success "System packages installed"

info "Installing Flask..."
pip3 install flask --quiet --break-system-packages 2>/dev/null || \
    pip3 install flask --quiet
success "Flask installed"

mkdir -p "$INSTALL_DIR/static" /etc/singbox-manager "$AUTO_CERT_DIR" /etc/sing-box
chmod 700 /etc/singbox-manager

if ! command -v sing-box >/dev/null 2>&1; then
    info "Downloading sing-box ${SINGBOX_VERSION}..."
    TMP_DIR="$(mktemp -d)"
    curl -L "${SINGBOX_URL}" -o "${TMP_DIR}/${SINGBOX_ARCHIVE}"
    tar -xzf "${TMP_DIR}/${SINGBOX_ARCHIVE}" -C "${TMP_DIR}"
    install -m 0755 "${TMP_DIR}"/sing-box-*/sing-box /usr/local/bin/sing-box
    rm -rf "${TMP_DIR}"
    success "sing-box installed to /usr/local/bin/sing-box"
else
    success "sing-box already installed: $(sing-box version | head -n 1)"
fi

UUID="$(cat /proc/sys/kernel/random/uuid)"
KEY_OUTPUT="$(sing-box generate reality-keypair)"
PRIVATE_KEY="$(echo "$KEY_OUTPUT" | awk '/PrivateKey:/ {print $2}')"
PUBLIC_KEY="$(echo "$KEY_OUTPUT" | awk '/PublicKey:/ {print $2}')"
SHORT_ID="$(sing-box generate rand --hex 8)"

[[ -z "${PRIVATE_KEY}" || -z "${PUBLIC_KEY}" ]] && error "Failed to generate Reality keypair"

success "Starter inbound credentials generated"
info "UUID: ${UUID}"
info "Public key: ${PUBLIC_KEY}"
info "Short ID: ${SHORT_ID}"

if [[ -f "${SINGBOX_CONFIG}" ]]; then
    cp -f "${SINGBOX_CONFIG}" "${SINGBOX_CONFIG}.bak.$(date +%s)"
    warn "Existing sing-box config backed up"
fi

cat > "${SINGBOX_CONFIG}" <<EOF
{
  "log": { "disabled": false },
  "inbounds": [
    {
      "type": "vless",
      "listen": "0.0.0.0",
      "listen_port": ${SINGBOX_PORT},
      "tag": "reality-vless",
      "users": [
        {
          "uuid": "${UUID}",
          "flow": "xtls-rprx-vision"
        }
      ],
      "tls": {
        "enabled": true,
        "server_name": "${SNI}",
        "reality": {
          "enabled": true,
          "handshake": {
            "server": "${SNI}",
            "server_port": 443
          },
          "private_key": "${PRIVATE_KEY}",
          "short_id": ["${SHORT_ID}"]
        }
      }
    }
  ],
  "outbounds": [
    { "type": "direct" }
  ]
}
EOF

info "Opening firewall ports with iptables..."
iptables -C INPUT -p tcp --dport "${SINGBOX_PORT}" -j ACCEPT 2>/dev/null || \
    iptables -I INPUT -p tcp --dport "${SINGBOX_PORT}" -j ACCEPT
iptables -C INPUT -p tcp --dport "${MANAGER_PORT}" -j ACCEPT 2>/dev/null || \
    iptables -I INPUT -p tcp --dport "${MANAGER_PORT}" -j ACCEPT
netfilter-persistent save >/dev/null 2>&1 || true
systemctl enable netfilter-persistent >/dev/null 2>&1 || true
systemctl start netfilter-persistent >/dev/null 2>&1 || true

cat > /etc/systemd/system/sing-box.service <<EOF
[Unit]
Description=Sing-box
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/sing-box run -c ${SINGBOX_CONFIG}
Restart=always
RestartSec=5
LimitNOFILE=4096
MemoryMax=128M

[Install]
WantedBy=multi-user.target
EOF

cp "${SCRIPT_DIR}/app.py" "${INSTALL_DIR}/app.py"
cp "${SCRIPT_DIR}/static/index.html" "${INSTALL_DIR}/static/index.html"
chmod +x "${INSTALL_DIR}/app.py"

SECRET_KEY="$(python3 -c "import secrets; print(secrets.token_hex(32))")"
cat > /etc/singbox-manager/env <<EOF
SECRET_KEY=${SECRET_KEY}
SINGBOX_CONFIG=${SINGBOX_CONFIG}
PASSWORD_FILE=${PASSWORD_FILE}
MANAGER_PORT=${MANAGER_PORT}
AUTO_CERT_DIR=${AUTO_CERT_DIR}
EOF
chmod 600 /etc/singbox-manager/env

cat > /etc/systemd/system/${SERVICE_NAME}.service <<EOF
[Unit]
Description=sing-box Proxy Manager Web UI
After=network.target sing-box.service
Wants=sing-box.service

[Service]
Type=simple
User=root
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=/etc/singbox-manager/env
ExecStart=$(command -v python3) ${INSTALL_DIR}/app.py
Restart=always
RestartSec=3
MemoryMax=128M
CPUQuota=20%

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable sing-box
systemctl restart sing-box
systemctl enable "${SERVICE_NAME}"
systemctl restart "${SERVICE_NAME}"

SERVER_IP="$(curl -4 -s --max-time 5 api.ipify.org || hostname -I | awk '{print $1}')"

echo ""
echo -e "${GREEN}  ✓ Installation complete!${NC}"
echo ""
echo "  Web UI:      http://${SERVER_IP}:${MANAGER_PORT}"
echo "  Manager log: journalctl -u ${SERVICE_NAME} -f"
echo "  sing-box log: journalctl -u sing-box -f"
echo ""
echo "  First visit will prompt you to set a password."
echo ""
echo "  Starter VLESS link:"
echo "  vless://${UUID}@${SERVER_IP}:${SINGBOX_PORT}?encryption=none&flow=xtls-rprx-vision&security=reality&sni=${SNI}&fp=chrome&pbk=${PUBLIC_KEY}&sid=${SHORT_ID}&type=tcp#Reality"
echo ""
echo "  Config:      ${SINGBOX_CONFIG}"
echo "  Auto certs:  ${AUTO_CERT_DIR}"
echo ""
