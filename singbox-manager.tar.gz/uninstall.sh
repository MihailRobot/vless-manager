#!/bin/bash
# Uninstall sing-box Proxy Manager and optional sing-box service/config

set -euo pipefail

[[ ${EUID} -ne 0 ]] && echo "Run as root" && exit 1

INSTALL_DIR="/opt/singbox-manager"
SERVICE_NAME="singbox-manager"
ENV_FILE="/etc/singbox-manager/env"
SINGBOX_CONFIG="/etc/sing-box/config.json"
MANAGER_PORT="8000"
SINGBOX_PORT=""

if [[ -f "${ENV_FILE}" ]]; then
    # shellcheck disable=SC1090
    source "${ENV_FILE}" || true
fi

if [[ -f "${SINGBOX_CONFIG}" ]]; then
    SINGBOX_PORT="$(python3 - <<'PY'
import json
try:
    with open("/etc/sing-box/config.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    inbounds = data.get("inbounds") or []
    print(inbounds[0].get("listen_port", ""))
except Exception:
    print("")
PY
)"
fi

echo "This will remove the web manager and can also remove sing-box."
read -r -p "Also remove sing-box binary, config, service, and generated certs? [y/N]: " REMOVE_SINGBOX

systemctl stop "${SERVICE_NAME}" 2>/dev/null || true
systemctl disable "${SERVICE_NAME}" 2>/dev/null || true
rm -f "/etc/systemd/system/${SERVICE_NAME}.service"

rm -rf "${INSTALL_DIR}"
rm -rf /etc/singbox-manager

iptables -D INPUT -p tcp --dport "${MANAGER_PORT}" -j ACCEPT 2>/dev/null || true

if [[ "${REMOVE_SINGBOX,,}" =~ ^(y|yes)$ ]]; then
    systemctl stop sing-box 2>/dev/null || true
    systemctl disable sing-box 2>/dev/null || true
    rm -f /etc/systemd/system/sing-box.service
    rm -f /usr/local/bin/sing-box
    rm -rf /etc/sing-box
    if [[ -n "${SINGBOX_PORT}" ]]; then
        iptables -D INPUT -p tcp --dport "${SINGBOX_PORT}" -j ACCEPT 2>/dev/null || true
    fi
fi

netfilter-persistent save >/dev/null 2>&1 || true
systemctl daemon-reload

echo "Uninstall complete."
